﻿using System;
using Microsoft.EntityFrameworkCore;

namespace Mission4.Models
{
    public class movieContext : DbContext
    {
        public movieContext(DbContextOptions<movieContext> options) : base (options)
        {

        }

        public DbSet<movieTemplate> Movies { get; set; }
        public DbSet<Category> Categories { get; set; }
 
        protected override void OnModelCreating(ModelBuilder mb)
        {

            mb.Entity<Category>().HasData(
                new Category
                {
                    CategoryId = 1,
                    CategoryName = "Action/Adventure"

                },
                 new Category
                 {
                     CategoryId = 2,
                     CategoryName = "Comedy"
                 },
                 new Category
                 {
                     CategoryId = 3,
                     CategoryName = "Drama"
                 },
                new Category
                {
                    CategoryId = 4,
                    CategoryName = "Horror"
                },
                new Category
                {
                    CategoryId = 5,
                    CategoryName = "Family"
                },
                new Category
                {
                    CategoryId = 6,
                    CategoryName = "Musical"
                }

            );

            mb.Entity<movieTemplate>().HasData(
               new movieTemplate
               {
                   MovieId = 1,
                   Title = "Hot Rod",
                   Year = 2009,
                   CategoryId = 2,
                   Director = "Sam Robertson",
                   Rating = "PG-13",
                   Edited = false,
                   Notes = "It's a great movie"
               },
                new movieTemplate
                {
                    MovieId = 2,
                    Title = "Blades of Glory",
                    Year = 2012,
                    CategoryId = 2,
                    Director = "Zach Barton",
                    Rating = "PG-13",
                    Edited = false,
                    Notes = "Kanye has a song that features this film"
                },
                new movieTemplate
                {
                    MovieId = 3,
                    Title = "La La Land",
                    Year = 2017,
                    CategoryId = 6,
                    Director = "Josh Baxter",
                    Rating = "PG-13",
                    Edited = false,
                    Notes = "If you don't like this movie then you need better opinions"
                }
           );
        }
    }
}
