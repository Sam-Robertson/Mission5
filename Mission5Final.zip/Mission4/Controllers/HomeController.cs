﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Mission4.Models;

namespace Mission4.Controllers
{
    public class HomeController : Controller
    {
        private movieContext blahContext { get; set; }

        public HomeController(movieContext movieCtx)
        {
            blahContext = movieCtx;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Podcasts()
        {
            return View("podcasts");
        }

        [HttpGet]
        public IActionResult SubmitMovie()
        {
            ViewBag.Categories = blahContext.Categories.ToList();

            return View("submitMovie");
        }

        [HttpPost]
        public IActionResult SubmitMovie(movieTemplate model)
        {
            if (ModelState.IsValid)
            {
            blahContext.Add(model);
            blahContext.SaveChanges();
            return View("confirmation", model);
            }
            else
            {
                ViewBag.Categories = blahContext.Categories.ToList();

                return View(model);
            }
            
        }
        [HttpGet]
        public IActionResult MovieList()
        {
            var movies = blahContext.Movies
                .Include(x => x.Category)
                .ToList();

            return View("movieList", movies);
        }
        [HttpGet]
        public IActionResult Edit(int id)
        {
            ViewBag.Categories = blahContext.Categories.ToList();

            var movie = blahContext.Movies.Single(x => x.MovieId == id);

            return View("editMovie", movie);
        }
        [HttpPost]
        public IActionResult Edit(movieTemplate movie)
        {
            if (ModelState.IsValid)
            {
                blahContext.Update(movie);
                blahContext.SaveChanges();
                return RedirectToAction("MovieList");
            }
            else
            {
                ViewBag.Categories = blahContext.Categories.ToList();

                return View("editMovie", movie);
            }  
        }
        public IActionResult Delete(int id)
        {
            var movie = blahContext.Movies.Single(x => x.MovieId == id);

            return View("deleteMovie", movie);
        }
        [HttpPost]
        public IActionResult Delete(movieTemplate movie)
        {
            blahContext.Movies.Remove(movie);
            blahContext.SaveChanges();

            return RedirectToAction("MovieList");
        }
    }
}
